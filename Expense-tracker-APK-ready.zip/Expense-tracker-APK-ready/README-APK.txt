Expense Tracker - APK Ready Project
===================================

This folder contains the original web app prepared for Capacitor Android conversion.

Web files are in: www/

App ID: com.noorzai.expensetracker
App name: د لګښت تعقیبونکی

Requirements on the computer:
- Node.js
- Android Studio
- Android SDK

Steps:
1. Open this project folder in a terminal.
2. Run:
   npm install
3. Add Android:
   npx cap add android
4. Sync the web files:
   npx cap sync android
5. Open the Android project:
   npx cap open android
6. In Android Studio, choose Build > Generate App Bundles or APKs > Generate APKs.

Important:
- The app stores transactions and the selected theme in localStorage, so the existing data logic remains offline.
- Do not move or rename files inside www unless you also update the HTML references.
- For a release APK, create a signing key and use Android Studio's signed APK flow.
